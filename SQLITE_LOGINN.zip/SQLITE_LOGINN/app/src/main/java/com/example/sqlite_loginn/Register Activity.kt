package com.example.sqlite_loginn

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RegisterActivity : AppCompatActivity() {
    private lateinit var db: DatabaseHelper
    private lateinit var regUsername: EditText
    private lateinit var regPassword: EditText
    private lateinit var regEmail: EditText
    private lateinit var regFullname: EditText
    private lateinit var register: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        db = DatabaseHelper(this)
        regUsername = findViewById(R.id.reg_username)
        regPassword = findViewById(R.id.reg_password)
        regEmail = findViewById(R.id.reg_email)
        regFullname = findViewById(R.id.reg_fullname)
        register = findViewById(R.id.register)

        register.setOnClickListener {
            val user = regUsername.text.toString()
            val pass = regPassword.text.toString()
            val email = regEmail.text.toString()
            val fullname = regFullname.text.toString()
            val isInserted = db.insertData(user, pass, email, fullname)
            if (isInserted) {
                Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Registro fallido", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

